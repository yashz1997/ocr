from django.http.response import JsonResponse
from django.views.generic.base import View, TemplateView
from django.views.decorators.csrf import csrf_exempt

from PIL import Image, ImageFilter
from tesserocr import PyTessBaseAPI
import numpy as np
import cv2
from matplotlib import pyplot as plt

'''
class OcrFormView(TemplateView):
    template_name = 'documents/ocr_form.html'
ocr_form_view = OcrFormView.as_view()


class OcrView(View):
    def post(self, request, *args, **kwargs):
        with PyTessBaseAPI() as api:
            with Image.open(request.FILES['image']) as image:
                sharpened_image = image.filter(ImageFilter.SHARPEN)
                api.SetImage(sharpened_image)
                utf8_text = api.GetUTF8Text()

        return JsonResponse({'utf8_text': utf8_text})
ocr_view = csrf_exempt(OcrView.as_view())
'''

class OcrFormView(TemplateView):
    template_name = 'documents/ocr_form.html'
ocr_form_view = OcrFormView.as_view()


class OcrView(View):
    def post(self, request, *args, **kwargs):
        with PyTessBaseAPI() as api:
            with Image.open(request.FILES['image']) as image:
                image.save("/tmp/%s" % request.FILES['image'])
                img = cv2.imread("/tmp/%s" % request.FILES['image'])
                #cv2.imshow("img", img)
                b,g,r = cv2.split(img)           # get b,g,r
                rgb_img = cv2.merge([r,g,b])     # switch it to rgb
		# Denoising
                dst = cv2.fastNlMeansDenoisingColored(img,None,10,10,7,21)
                #b,g,r = cv2.split(dst)           # get b,g,r
                #rgb_dst = cv2.merge([r,g,b])     # switch it to rgb
                weighted = cv2.addWeighted(rgb_img, 0.4, img, 0.7, 0)   # Now the weight of the img1 is 60% and that of img2 is 40% and gamma = 0
                height, width = weighted.shape[:2]
                res = cv2.resize(weighted, (4*width, 4*height), interpolation = cv2.INTER_CUBIC)
                cv2.imwrite("/tmp/%s" % request.FILES['image'], res)
                api.SetImageFile("/tmp/%s" % request.FILES['image'])
                utf8_text = api.GetUTF8Text()

        return JsonResponse({'utf8_text': utf8_text})
ocr_view = csrf_exempt(OcrView.as_view())









