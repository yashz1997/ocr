import cv2
import numpy as np
import matplotlib.pyplot as plt

cap = cv2.VideoCapture(1)      # Here 1 represents WebCam number 1 
fourcc =fourcc = cv2.cv.CV_FOURCC(*'XVID')      # This is supported by every system and this is used to output the file 
out = cv2.VideoWriter("output.avi", fourcc, 20.0, (640,480)) # OUTPUT of the video will be stored here frame by frame 

while True:
	ref, frame = cap.read()
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)   # Each frame is converted into GrayScale
	out.write(frame) # Out will write to the output file 
	cv2.imshow("frame", frame)
	cv2.imshow("gray", gray)
	
	if cv2.WaitKey(1) & OxFF == ord("q"):      # If key "q" is pressed the the loop will exit
		break

cap.release()   # This will release the camera 
out.release()   # This will release the output video file 
cv2.destroyAllWindows()



















































