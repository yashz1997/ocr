import cv2
import numpy as np

img = cv2.imread("watch.jpeg", cv2.IMREAD_COLOR)


img[55,55] = [0,0,0]   # Point (55,55) will be of black dot


img[100:150,100:150] = [255,255,255]     # Square portion will be filled with white color
px = img[100:150,100:150]
print(px)

watch_face = img[60:160,50:167]    # Copy and Paste in Image itself
img[0:100,0:117] = watch_face

cv2.imshow('image',img)
cv2.waitKey(0)
cv2.destroyAllWindows()











































