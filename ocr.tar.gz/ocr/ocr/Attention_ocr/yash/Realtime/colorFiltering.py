import cv2
import numpy as np

img = cv2.imread("tes1.png")
while(1):
    

    laplacian = cv2.Laplacian(img,cv2.CV_64F)
    sobelx = cv2.Sobel(img,cv2.CV_64F,1,0,ksize=5)
    sobely = cv2.Sobel(img,cv2.CV_64F,0,1,ksize=5)
    edges = cv2.Canny(img,90,90)
    blur = cv2.GaussianBlur(edges,(15,15),0)
    #cv2.imshow("Image",img) 
    cv2.imshow("laplacian",laplacian)
    #cv2.imshow("sobelx",sobelx)
    #cv2.imshow("sobely",sobely)   
    #cv2.imshow("edges",edges)   
    #cv2.imshow("blur",blur) 
    cv2.imwrite('backwhite.png',laplacian)
    k = cv2.waitKey(5) & 0xFF
    if k == 27:       # Wait for ESC key to exit
        break

cv2.waitKey(0)
cv2.destroyAllWindows()
cap.release()






############# IMAGE With Bluring Effect#################################
"""
cap = cv2.imread("wiki.png")
while(1):
    #_, frame = cap.read()
    hsv = cv2.cvtColor(cap, cv2.COLOR_BGR2HSV)	
     
    # wiki.png
    lower_red = np.array([0,0,0])
    upper_red = np.array([190,190,255])
    

    ''' #redcap.jpeg
    lower_red = np.array([160,150,10])
    upper_red = np.array([255,255,255])
    '''

    mask = cv2.inRange(hsv, lower_red, upper_red)
    res = cv2.bitwise_and(cap,cap, mask= mask)
 
    blur = cv2.GaussianBlur(res,(15,15),0)
    cv2.imshow('Gaussian Blurring',blur)

    bilateral = cv2.bilateralFilter(res,15,75,75)
    #cv2.imshow('bilateral Blur',bilateral)
    
    median = cv2.medianBlur(res,15)
    #cv2.imshow('Median Blur',median)

    cv2.imshow('frame',cap)
    #cv2.imshow('mask',mask)
    cv2.imshow('res',res)
    
    k = cv2.waitKey(5) & 0xFF
    if k == 27:       # Wait for ESC key to exit
        break

cv2.waitKey(0)
cv2.destroyAllWindows()
cap.release()

"""


####################### VIDEO With Bluring Effect#################################
"""
import cv2
import numpy as np

cap = cv2.VideoCapture("coals.mov")

while(1):
    _, frame = cap.read()
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    
    lower_red = np.array([30,150,50])
    upper_red = np.array([255,255,180])
    
    mask = cv2.inRange(hsv, lower_red, upper_red)
    res = cv2.bitwise_and(frame,frame, mask= mask)
 
    blur = cv2.GaussianBlur(res,(15,15),0)
    #cv2.imshow('Gaussian Blurring',blur)

    bilateral = cv2.bilateralFilter(res,15,75,75)
    #cv2.imshow('bilateral Blur',bilateral)

    median = cv2.medianBlur(res,15)
    #cv2.imshow('Median Blur',median)

    cv2.imshow('frame',frame)
    #cv2.imshow('mask',mask)
    cv2.imshow('res',res)
    
    k = cv2.waitKey(5) & 0xFF
    if k == 27:       # Wait for ESC key to exit
        break

cv2.destroyAllWindows()
cap.release()

"""
