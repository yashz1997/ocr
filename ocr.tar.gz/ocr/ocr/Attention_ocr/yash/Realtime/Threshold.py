import cv2
import numpy as np

img = cv2.imread('tes1.png')
cv2.imshow('original',img)

##########################################################

retval, threshold = cv2.threshold(img, 12, 255, cv2.THRESH_BINARY)  # TECHNIQUE 1   Type of Threshold = cv2.THRESH_BINARY
cv2.imshow('Hello',threshold)

##########################################################

grayscaled = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
retval, threshold = cv2.threshold(grayscaled, 10, 255, cv2.THRESH_BINARY)
img = cv2.imshow('Yash',threshold)

##########################################################

th = cv2.adaptiveThreshold(grayscaled, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 115, 2)
cv2.imshow('Adaptive threshold',th)

#########################################################

retval2,threshold2 = cv2.threshold(grayscaled,125,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)   # This Threshold is not helpfull with this image
cv2.imshow('Otsu threshold',threshold)

#########################################################
#edges = cv2.Canny(th,90,90)
#blur = cv2.GaussianBlur(edges,(15,15),-12)
#cv2.imshow("blur",blur)

#cv2.imwrite('output.png',img)
cv2.imwrite('newImage.png',th)
cv2.waitKey(0)
cv2.destroyAllWindows()
