import cv2
import numpy as np


img1 = cv2.imread("tes1.png")
img2 = cv2.imread("Screenshot_1.png")
#img1gray = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
#img2gray = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
#histeq = cv2.equalizeHist(img2gray)
#add = cv2.add(img2gray, img2gray)


'''
add = cv2.add(img2, img2)
weighted = cv2.addWeighted(img1gray, 0.4, img2gray, 0.7, 0)   # Now the weight of the img1 is 60% and that of img2 is 40% and gamma = 0
cv2.imshow("Weighted", weighted)
#cv2.imwrite('add.png',weighted)


'''




##################### ADD IMAGES ########################

add = img1 + img2  # Image should of the same size 

add = cv2.add(img2, img2)   # Here 2 pixels are added so it will show a bright picture

weighted = cv2.addWeighted(img1, 0.5, img2, 0.5, 0)   # Now the weight of the img1 is 60% and that of img2 is 40% and gamma = 0
cv2.imshow("Weighted", weighted)
cv2.imshow("orignal",img2)
#cv2.imwrite('add.png',weighted)

cv2.imwrite('13test.png',weighted)
cv2.waitKey(0)
cv2.destroyAllWindows()

















































