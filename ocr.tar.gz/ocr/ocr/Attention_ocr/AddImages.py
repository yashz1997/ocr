import cv2
import numpy as np


img1 = cv2.imread("newImage.png")
img2 = cv2.imread("12.png")

##################### ADD IMAGES ########################

# add = img1 + img2  # Image should of the same size 

add = cv2.add(img2, img2)   # Here 2 pixels are added so it will show a bright picture

weighted = cv2.addWeighted(img1, 0.4, img2, 0.7, 0)   # Now the weight of the img1 is 60% and that of img2 is 40% and gamma = 0
cv2.imshow("Weighted", weighted)
#cv2.imwrite('add.png',weighted)
cv2.waitKey(0)
cv2.destroyAllWindows()

















































