from django.apps import AppConfig


class OCRConfig(AppConfig):
    name = 'OCR'
