import datetime
from haystack import indexes
from instructions.models import Instructions

class InstructionsIndex(indexes.SearchIndex, indexes.Indexable):
    text = indexes.CharField(document=True, use_template=True)
    instruction = indexes.CharField(model_attr='phrase')
    instruction_type = indexes.CharField(model_attr='instruction_type')
    action = indexes.CharField(model_attr='action')
    action_type = indexes.CharField(model_attr='action')
    target = indexes.CharField(model_attr='target')
    command = indexes.CharField(model_attr='command')


    def get_model(self):
        return Instructions

    def prepare_action(self, obj):
        return '' if not obj.action else obj.action.action

    def prepare_action_type(self, obj):
        return '' if not obj.action else obj.action.type.name

    def prepare_instruction_type(self, obj):
        return '' if not obj.instruction_type else obj.instruction_type.name

    def index_queryset(self, using=None):
        """Used when the entire index for model is updated."""
        return self.get_model().objects.all()
