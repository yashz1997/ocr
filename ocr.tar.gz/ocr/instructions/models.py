from django.db import models
from django.utils import timezone
from django.utils.translation import ugettext_lazy as _

class ActionType(models.Model):
    name = models.CharField(max_length=100, verbose_name=_('Action Type Name'), help_text=_('Action Type Name'), db_index=True)
    description = models.TextField(verbose_name=_('Description'), help_text=_('Description'), db_index=True)

    class Meta:
        verbose_name = 'Action Type'
        verbose_name_plural = 'Action Types'

    def __str__(self):
        return str("%s" % (self.name))


class Action(models.Model):
    action = models.CharField(max_length=100, verbose_name=_('Action Type Name'), help_text=_('Action Type Name'), db_index=True)
    type = models.ForeignKey(ActionType, verbose_name=_('Action Type'), help_text=_('Action Type'), related_name="type_actions", db_index=True)
    # split_value_by = models.TextField(verbose_name=_('Action Value Split By'), help_text=_('Add multiple values with pipe ("|") sign'), null=True, blank=True, db_index=True)
    description = models.TextField(verbose_name=_('Description'), help_text=_('Description'), db_index=True)

    class Meta:
        verbose_name = 'Action'
        verbose_name_plural = 'Actions'

    def __str__(self):
        return str("%s - %s" % (self.action, self.type))


class InstructionType(models.Model):
    name = models.CharField(max_length=100, verbose_name=_('Instruction Type Name'), help_text=_('Instruction Type Name'), db_index=True)
    description = models.TextField(verbose_name=_('Description'), help_text=_('Description'), db_index=True)

    class Meta:
        verbose_name = 'Instruction Type'
        verbose_name_plural = 'Instruction Types'

    def __str__(self):
        return str("%s" % (self.name))


class Instructions(models.Model):
    TARGET_DEVICE = (
    ('web', 'Web'),
    ('mobile', 'Mobile'),
    ('desktop', 'Desktop'),
    ('device', 'Handheld Device'),
)
    phrase = models.CharField(max_length=512, verbose_name=_('Phrase'), help_text=_('Phrase'), db_index=True)
    instruction_type = models.ForeignKey(InstructionType, verbose_name=_('Instruction Type'), help_text=_('Instruction Type'),
                       blank=True, null=True, related_name="instruction_type", db_index=True)
    action = models.ForeignKey(Action, verbose_name=_('Action'), help_text=_('Action'), related_name="action_instructions", db_index=True)
    target = models.CharField(max_length=100, verbose_name=_('Target'), help_text=_('Target'), choices=TARGET_DEVICE, default="web", db_index=True)
    command = models.TextField(verbose_name=_('Command'), help_text=_('Command'), default="", db_index=True)
    active = models.BooleanField(verbose_name=_('Active'), default=True)

    class Meta:
        verbose_name = 'Instruction'
        verbose_name_plural = 'Instructions'

    def __str__(self):
        return str("%s - %s - %s" % (self.phrase, self.action, self.target))


class ConfigurationType(models.Model):
    name = models.CharField(max_length=100, verbose_name=_('Configuration Type Name'), help_text=_('Configuration Type Name'), db_index=True)
    description = models.TextField(verbose_name=_('Description'), help_text=_('Description'), db_index=True)

    class Meta:
        verbose_name = 'Configuration Type'
        verbose_name_plural = 'Configuration Types'

    def __str__(self):
        return str("%s" % (self.name))


class Configuration(models.Model):
    value = models.TextField(verbose_name=_('Configuration Value'), help_text=_('Configuration Value'), db_index=True)
    type = models.ForeignKey(ConfigurationType, verbose_name=_('Configuration Type'), help_text=_('Configuration Type'), related_name="type_configurations", db_index=True)
    description = models.TextField(verbose_name=_('Description'), help_text=_('Description'), db_index=True)

    class Meta:
        verbose_name = 'Configuration'
        verbose_name_plural = 'Configurations'

    def __str__(self):
        return str("%s - %s" % (self.value, self.type))
