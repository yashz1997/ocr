from django.apps import AppConfig

class InstructionConfig(AppConfig):
    name = "instructions"
