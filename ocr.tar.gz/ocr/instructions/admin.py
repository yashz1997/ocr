# -*- coding: utf-8 -*-
from django.contrib import admin

from .models import ActionType, Action, Instructions, InstructionType, ConfigurationType, Configuration


@admin.register(ConfigurationType)
class ConfigurationTypeAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')
    search_fields = ('name',)


@admin.register(Configuration)
class ConfigurationAdmin(admin.ModelAdmin):
    list_display = ('value', 'type', 'description')
    list_filter = ('type',)


@admin.register(ActionType)
class ActionTypeAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')
    search_fields = ('name',)


@admin.register(Action)
class ActionAdmin(admin.ModelAdmin):
    list_display = ('action', 'type', 'description')
    list_filter = ('type',)


@admin.register(InstructionType)
class InstructionTypeAdmin(admin.ModelAdmin):
    list_display = ('name', 'description')
    search_fields = ('name',)


@admin.register(Instructions)
class InstructionsAdmin(admin.ModelAdmin):
    list_display = ('phrase', 'action', 'target', 'active')
    list_filter = ('action', 'active')
