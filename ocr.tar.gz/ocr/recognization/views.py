import re
import sys
import json
import base64
import struct
from operator import itemgetter
from django.shortcuts import render
from django.conf import settings
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

from instructions.models import Configuration

import os
os.environ['TF_CPP_MIN_LOG_LEVEL']='2'

import tensorflow as tf
import speech_recognition as sr

from elasticsearch2 import Elasticsearch
es = Elasticsearch([{'host': 'localhost', 'port': 9200}])


def handle_uploaded_file(f):
    filename = "%s/%s" % (settings.MEDIA_ROOT, f.name)
    with open(filename, 'wb+') as destination:
        for chunk in f.chunks():
            destination.write(chunk)
    return filename

@csrf_exempt
def ImageRecognize(request):
    if request.method == 'POST' and request.FILES:
        filename = handle_uploaded_file(request.FILES['file'])

        lst = []

        # Read in the image_data
        image_data = tf.gfile.FastGFile(filename, 'rb').read()

        # Loads label file, strips off carriage return
        labels_file = "%s/%s" % (settings.TENSORFLOW_DATA, 'retrained_labels.txt')
        label_lines = [line.rstrip() for line in tf.gfile.GFile(labels_file)]

        # Unpersists graph from file
        graph_file = "%s/%s" % (settings.TENSORFLOW_DATA, 'retrained_graph.pb')
        with tf.gfile.FastGFile(graph_file, 'rb') as f:
            graph_def = tf.GraphDef()
            graph_def.ParseFromString(f.read())
            _ = tf.import_graph_def(graph_def, name='')

        with tf.Session() as sess:
            # Feed the image_data as input to the graph and get first prediction
            softmax_tensor = sess.graph.get_tensor_by_name('final_result:0')

            predictions = sess.run(softmax_tensor, {'DecodeJpeg/contents:0': image_data})

            # Sort to show labels of first prediction in order of confidence
            top_k = predictions[0].argsort()[-len(predictions[0]):][::-1]

            for node_id in top_k:
                human_string = label_lines[node_id]
                score = round(predictions[0][node_id] * 100, 2)
                #output_str = ('%s (Match = %.2f%%)' % (human_string.capitalize(), score))
                output_str = ('%s' % (human_string.capitalize()))
                output_str = output_str.replace("Tv", "TV")
                output_str = output_str.replace("Bbq", "BBQ")
                #print(output_str)
                lst.append(output_str)
			
        return HttpResponse(json.dumps(lst))
    else:
        return HttpResponse(json.dumps([]))


PHRASE_SPLIT = 'and type|at type|type|enter|and enter|at enter|insert|and insert|at insert|and fill|fill|at fill|and tie|and try'

@csrf_exempt
def SpeechRecognize(request):
    if request.method == 'POST':
        filename = "%s/%s" % (settings.MEDIA_ROOT, request.POST["file"])
        str_wav = request.POST["data"].split("data:audio/wav;base64,")[1]

        with open(filename, 'wb') as file:
            file.write(base64.b64decode(str_wav))

        r = sr.Recognizer()
        with sr.AudioFile(filename) as source:        # use "myspeech.wav" as the audio source
            audio = r.record(source)                  # extract audio data from the file

        try:
            value = r.recognize_google(audio, language="en-IN")
            if value:
                print("STT: ", value)

                phrase_split = Configuration.objects.filter(type__name="PHRASE_SPLIT")
                if phrase_split.exists():
                    PHRASE_SPLIT= phrase_split[0].value

                phrase_regex = re.compile(PHRASE_SPLIT)
                value_list = phrase_regex.split(value)
                matches = phrase_regex.findall(value)
                input_data = value_list.pop()

                phrase = value
                if len(value_list) == 1:
                    phrase = value_list[0]
                elif len(value_list) >= 2:
                    phrase = "".join(value_list)

                if len(matches) > 1:
                    phrase += matches[0]

                print("Instruction: ", phrase)

                if str is bytes:  # this version of Python uses bytes for strings (Python 2)
                    result = es.search(index="haystack", body={"query": {"match": {"instruction": {"query": u"".format(phrase).encode("utf-8"), "operator" : "and", "zero_terms_query": "all", "fuzziness": 1}}}})
                else:  # this version of Python uses unicode for strings (Python 3+)
                    result = es.search(index="haystack", body={"query": {"match": {"instruction": {"query": "{}".format(phrase), "operator" : "and", "zero_terms_query": "all", "fuzziness": 1}}}})

                if len(result["hits"]["hits"]) > 0 and result["hits"]["hits"][0]["_score"] > 0.20:
                    data = {
                            "stt": value,
                            "instruction": result["hits"]["hits"][0]["_source"]["instruction"],
                            "action": result["hits"]["hits"][0]["_source"]["action"],
                            "action_type": result["hits"]["hits"][0]["_source"]["action_type"],
                            "target": result["hits"]["hits"][0]["_source"]["target"],
                            "command": result["hits"]["hits"][0]["_source"]["command"],
                            "score": result["hits"]["hits"][0]["_score"],
                            "value": input_data
                           }
                    return HttpResponse(json.dumps(data))
                else:
                    return HttpResponse(json.dumps({"stt": value}))

        except IndexError:                                  # the API key didn't work
            return HttpResponse(json.dumps({"error": "No internet connection"}))
        except KeyError:                                    # the API key didn't work
            return HttpResponse(json.dumps({"error": "Invalid API key or quota maxed out"}))
        except LookupError:                                 # speech is unintelligible
            return HttpResponse(json.dumps({"error": "Could not understand audio"}))
        except sr.UnknownValueError:
            return HttpResponse(json.dumps({"error": "Google Speech Recognition could not understand audio"}))
        except sr.RequestError as e:
            return HttpResponse(json.dumps({"error": "Could not request results from Google Speech Recognition service; {0}".format(e)}))

    return HttpResponse(json.dumps({}))

