from django.apps import AppConfig


class RecognizationConfig(AppConfig):
    name = 'recognization'
